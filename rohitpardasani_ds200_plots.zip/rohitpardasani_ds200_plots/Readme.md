Datasets selected from https://data.gov.in/ 
Data Used : Area, Population and Income of G-20 Countries upto 2013
https://data.gov.in/resources/area-population-and-income-g-20-countries-upto-2013

Scatter Plot : Area vs Population of Countries
Box Plot : Population of Countries in 3 consecutive year
Bar Plot : Area of countries 

All three plots and scripts in a single file PlotsAssignment.ipynb (Python Jupyter Notebook)

Scatter Plot: Gives an idea about the population density of countries. Example: a country in top left will be one with very high density and one on bottom right will be one with very low density.

Box Plot: Depicts population data of countries in consecutive years. Not much variation in the overall distribution in three consecutive years. 

Bar Plot: Comparison among area of countries. Clearly Russia stands out among the group.
